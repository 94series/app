// src/routes.jsx
import { createBrowserRouter } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Analytics from './pages/Analytics';
import ConnectPartner from './pages/ConnectPartner';
import ErrorBoundary from './components/common/ErrorBoundary';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    errorElement: <ErrorBoundary />,
    children: [
      {
        path: '/',
        element: <Home />,
        errorElement: <ErrorBoundary />,
      },
      {
        path: '/analytics',
        element: <Analytics />,
        errorElement: <ErrorBoundary />,
      },
      {
        path: '/connect',
        element: <ConnectPartner />,
        errorElement: <ErrorBoundary />,
      },
    ],
  },
  {
    path: '/login',
    element: <Login />,
    errorElement: <ErrorBoundary />,
  },
]);

export default router;