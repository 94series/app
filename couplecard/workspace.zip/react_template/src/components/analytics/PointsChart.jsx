// src/components/analytics/PointsChart.jsx
import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

const PointsChart = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const chart = echarts.init(chartRef.current);
    
    // Demo data - in real app, this would come from backend
    const data = {
      dates: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      earned: [30, 45, 25, 60, 35, 50, 40],
      spent: [20, 35, 15, 40, 25, 30, 20]
    };

    const option = {
      title: {
        text: 'Points Activity',
        left: 'center'
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['Points Earned', 'Points Spent'],
        top: '30px'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '70px',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: data.dates
      },
      yAxis: {
        type: 'value',
        name: 'Points'
      },
      series: [
        {
          name: 'Points Earned',
          type: 'bar',
          data: data.earned,
          itemStyle: {
            color: '#FF69B4'
          },
          emphasis: {
            itemStyle: {
              color: '#FF1493'
            }
          }
        },
        {
          name: 'Points Spent',
          type: 'bar',
          data: data.spent,
          itemStyle: {
            color: '#87CEEB'
          },
          emphasis: {
            itemStyle: {
              color: '#4169E1'
            }
          }
        }
      ]
    };

    chart.setOption(option);

    const handleResize = () => {
      chart.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      chart.dispose();
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div ref={chartRef} className="w-full h-[400px]" />
    </div>
  );
};

export default PointsChart;