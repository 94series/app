// src/components/analytics/EmotionHeatmap.jsx
import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

const EmotionHeatmap = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const chart = echarts.init(chartRef.current);
    
    // Demo data - in real app, this would come from backend
    const hours = ['12a', '1a', '2a', '3a', '4a', '5a', '6a', '7a', '8a', '9a', '10a', '11a',
      '12p', '1p', '2p', '3p', '4p', '5p', '6p', '7p', '8p', '9p', '10p', '11p'];
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const data = [];
    for (let i = 0; i < 7; i++) {
      for (let j = 0; j < 24; j++) {
        data.push([j, i, Math.random() * 100]);
      }
    }

    const option = {
      title: {
        text: 'Emotional Interactions',
        left: 'center'
      },
      tooltip: {
        position: 'top',
        formatter: (params) => {
          return `${days[params.value[1]]} ${hours[params.value[0]]}<br>Intensity: ${params.value[2].toFixed(1)}`;
        }
      },
      grid: {
        top: '60px',
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: hours,
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: days,
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 0,
        max: 100,
        calculable: true,
        orient: 'horizontal',
        left: 'center',
        bottom: '0%',
        inRange: {
          color: ['#FFE6E6', '#FF69B4', '#FF1493']
        }
      },
      series: [{
        name: 'Emotion Intensity',
        type: 'heatmap',
        data: data,
        label: {
          show: false
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }]
    };

    chart.setOption(option);

    const handleResize = () => {
      chart.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      chart.dispose();
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div ref={chartRef} className="w-full h-[400px]" />
    </div>
  );
};

export default EmotionHeatmap;