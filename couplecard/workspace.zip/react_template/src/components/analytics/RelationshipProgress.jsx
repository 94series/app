// src/components/analytics/RelationshipProgress.jsx
import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';

const RelationshipProgress = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const chart = echarts.init(chartRef.current);
    
    // Demo data - in real app, this would come from backend
    const data = {
      categories: ['Communication', 'Understanding', 'Trust', 'Support', 'Growth'],
      current: [85, 72, 90, 68, 75],
      target: [100, 100, 100, 100, 100]
    };

    const option = {
      title: {
        text: 'Relationship Progress',
        left: 'center'
      },
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['Current Level', 'Target Level'],
        top: '30px'
      },
      radar: {
        indicator: data.categories.map(category => ({
          name: category,
          max: 100
        })),
        splitArea: {
          areaStyle: {
            color: ['#FFF0F5', '#FFE1EE', '#FFD2E7', '#FFC3E0', '#FFB4D9']
          }
        }
      },
      series: [{
        name: 'Progress Levels',
        type: 'radar',
        data: [
          {
            value: data.current,
            name: 'Current Level',
            itemStyle: {
              color: '#FF69B4'
            },
            areaStyle: {
              color: 'rgba(255, 105, 180, 0.3)'
            }
          },
          {
            value: data.target,
            name: 'Target Level',
            lineStyle: {
              type: 'dashed',
              color: '#FFC0CB'
            },
            itemStyle: {
              color: '#FFC0CB'
            },
            areaStyle: {
              color: 'rgba(255, 192, 203, 0.1)'
            }
          }
        ]
      }]
    };

    chart.setOption(option);

    const handleResize = () => {
      chart.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      chart.dispose();
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div ref={chartRef} className="w-full h-[400px]" />
    </div>
  );
};

export default RelationshipProgress;