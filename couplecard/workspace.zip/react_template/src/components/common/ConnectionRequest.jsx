// src/components/common/ConnectionRequest.jsx
import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useAuth } from '../../hooks/useAuth';
import { addNotification } from '../../store/notificationSlice';
import { listenToConnectionRequests, handleConnectionRequest } from '../../services/database';
import { ref, get } from 'firebase/database';
import { database } from '../../config/firebase';

const ConnectionRequest = () => {
  const dispatch = useDispatch();
  const [requests, setRequests] = useState([]);
  const [requestDetails, setRequestDetails] = useState({});
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Listen for connection requests and fetch user details
    const unsubscribe = listenToConnectionRequests(user.userId, async (newRequests) => {
      const details = {};
      
      // Fetch sender details for each request
      for (const request of newRequests) {
        try {
          const senderSnapshot = await get(ref(database, `users/${request.fromUserId}`));
          if (senderSnapshot.exists()) {
            details[request.id] = {
              account: senderSnapshot.val().account,
              nickname: senderSnapshot.val().nickname
            };
          }
        } catch (error) {
          console.error('Error fetching sender details:', error);
        }
      }
      
      setRequestDetails(details);
      setRequests(newRequests);
    });

    return () => unsubscribe();
  }, [user]);

  const handleAccept = async (request) => {
    try {
      await handleConnectionRequest(request.id, 'accepted', request.fromUserId, user.userId);
      dispatch(addNotification({
        type: 'success',
        title: 'Connection Accepted',
        message: `You are now connected with ${requestDetails[request.id]?.account || 'your partner'}!`
      }));
    } catch (error) {
      dispatch(addNotification({
        type: 'error',
        title: 'Connection Failed',
        message: error.message
      }));
    }
  };

  const handleReject = async (request) => {
    try {
      await handleConnectionRequest(request.id, 'rejected', request.fromUserId, user.userId);
      dispatch(addNotification({
        type: 'info',
        title: 'Connection Rejected',
        message: `You have rejected the connection request from ${requestDetails[request.id]?.account || 'a user'}.`
      }));
    } catch (error) {
      dispatch(addNotification({
        type: 'error',
        title: 'Request Failed',
        message: error.message
      }));
    }
  };

  if (requests.length === 0) {
    return null;
  }

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="mt-8 bg-white shadow-lg rounded-lg p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Connection Requests</h3>
      <div className="space-y-4">
        {requests.map((request) => (
          <div
            key={request.id}
            className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors duration-200"
          >
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <span className="font-medium text-gray-900">
                  {requestDetails[request.id]?.nickname || 'Unknown User'}
                </span>
                <span className="text-sm text-gray-500">
                  ({requestDetails[request.id]?.account || 'loading...'})
                </span>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                Sent at: {formatTimestamp(request.createdAt)}
              </p>
            </div>
            <div className="flex space-x-2 ml-4">
              <button
                onClick={() => handleAccept(request)}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200"
              >
                Accept
              </button>
              <button
                onClick={() => handleReject(request)}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors duration-200"
              >
                Reject
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConnectionRequest;