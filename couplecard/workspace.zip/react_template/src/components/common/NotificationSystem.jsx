// src/components/common/NotificationSystem.jsx
import React, { Fragment, useEffect } from 'react';
import { Transition } from '@headlessui/react';
import { useSelector, useDispatch } from 'react-redux';
import { removeNotification } from '../../store/notificationSlice';

const NotificationSystem = () => {
  const notifications = useSelector(state => state.notifications.items);
  const dispatch = useDispatch();

  // Auto-dismiss notifications after 5 seconds
  useEffect(() => {
    if (notifications.length > 0) {
      const timer = setTimeout(() => {
        dispatch(removeNotification(notifications[0].id));
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [notifications, dispatch]);

  const getNotificationStyle = (type) => {
    switch (type) {
      case 'success':
        return {
          container: 'bg-green-50 border-green-500',
          icon: 'text-green-400',
          title: 'text-green-800',
          message: 'text-green-700',
          close: 'text-green-500 hover:text-green-600'
        };
      case 'error':
        return {
          container: 'bg-red-50 border-red-500',
          icon: 'text-red-400',
          title: 'text-red-800',
          message: 'text-red-700',
          close: 'text-red-500 hover:text-red-600'
        };
      case 'warning':
        return {
          container: 'bg-yellow-50 border-yellow-500',
          icon: 'text-yellow-400',
          title: 'text-yellow-800',
          message: 'text-yellow-700',
          close: 'text-yellow-500 hover:text-yellow-600'
        };
      case 'info':
        return {
          container: 'bg-blue-50 border-blue-500',
          icon: 'text-blue-400',
          title: 'text-blue-800',
          message: 'text-blue-700',
          close: 'text-blue-500 hover:text-blue-600'
        };
      default:
        return {
          container: 'bg-gray-50 border-gray-500',
          icon: 'text-gray-400',
          title: 'text-gray-800',
          message: 'text-gray-700',
          close: 'text-gray-500 hover:text-gray-600'
        };
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success':
        return (
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
          </svg>
        );
      case 'error':
        return (
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        );
      case 'warning':
        return (
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        );
      case 'info':
        return (
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end px-4 py-6 pointer-events-none sm:p-6">
      <div className="w-full flex flex-col items-center space-y-4">
        {notifications.map((notification) => (
          <Transition
            key={notification.id}
            as={Fragment}
            show={true}
            enter="transform ease-out duration-300 transition"
            enterFrom="translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2"
            enterTo="translate-y-0 opacity-100 sm:translate-x-0"
            leave="transition ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <div
              className={`max-w-sm w-full shadow-lg rounded-lg pointer-events-auto border-l-4 ${
                getNotificationStyle(notification.type).container
              }`}
            >
              <div className="p-4">
                <div className="flex items-start">
                  <div className={`flex-shrink-0 ${getNotificationStyle(notification.type).icon}`}>
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="ml-3 w-0 flex-1">
                    <p className={`text-sm font-medium ${getNotificationStyle(notification.type).title}`}>
                      {notification.title}
                    </p>
                    <p className={`mt-1 text-sm ${getNotificationStyle(notification.type).message}`}>
                      {notification.message}
                    </p>
                  </div>
                  <div className="ml-4 flex-shrink-0 flex">
                    <button
                      className={`rounded-md inline-flex focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 ${
                        getNotificationStyle(notification.type).close
                      }`}
                      onClick={() => dispatch(removeNotification(notification.id))}
                    >
                      <span className="sr-only">Close</span>
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </Transition>
        ))}
      </div>
    </div>
  );
};

export default NotificationSystem;