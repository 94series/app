// src/components/common/Card.jsx
import React from 'react';
import PropTypes from 'prop-types';

const Card = ({ id, type, title, content, description, points, status, icon, onClick }) => {
  const cardTypes = {
    diary: {
      bg: 'bg-pink-100',
      border: 'border-pink-300',
      hover: 'hover:border-pink-500',
      shadow: 'shadow-pink-100',
      text: 'text-pink-800'
    },
    task: {
      bg: 'bg-blue-100',
      border: 'border-blue-300',
      hover: 'hover:border-blue-500',
      shadow: 'shadow-blue-100',
      text: 'text-blue-800'
    },
    tool: {
      bg: 'bg-purple-100',
      border: 'border-purple-300',
      hover: 'hover:border-purple-500',
      shadow: 'shadow-purple-100',
      text: 'text-purple-800'
    },
    convention: {
      bg: 'bg-green-100',
      border: 'border-green-300',
      hover: 'hover:border-green-500',
      shadow: 'shadow-green-100',
      text: 'text-green-800'
    },
    punishment: {
      bg: 'bg-red-100',
      border: 'border-red-300',
      hover: 'hover:border-red-500',
      shadow: 'shadow-red-100',
      text: 'text-red-800'
    },
    wish: {
      bg: 'bg-yellow-100',
      border: 'border-yellow-300',
      hover: 'hover:border-yellow-500',
      shadow: 'shadow-yellow-100',
      text: 'text-yellow-800'
    }
  };

  const cardStyle = cardTypes[type] || {
    bg: 'bg-gray-100',
    border: 'border-gray-300',
    hover: 'hover:border-gray-500',
    shadow: 'shadow-gray-100',
    text: 'text-gray-800'
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500 text-white';
      case 'ongoing':
        return 'bg-blue-500 text-white';
      case 'locked':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-white text-gray-700';
    }
  };

  return (
    <div 
      className={`
        relative rounded-xl p-6 border-2 cursor-pointer
        transform transition-all duration-300 ease-in-out
        ${cardStyle.bg} ${cardStyle.border} ${cardStyle.hover}
        hover:scale-105 hover:shadow-xl ${cardStyle.shadow}
        ${status === 'locked' ? 'opacity-60' : 'opacity-100'}
      `}
      onClick={onClick}
    >
      {/* Points Badge */}
      <div className="absolute -top-3 -right-3 bg-white rounded-full px-3 py-1 shadow-md border border-gray-200">
        <span className="text-pink-600 font-bold">{points}pts</span>
      </div>

      {/* Card Content */}
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center mb-4">
          <span className="text-2xl mr-3">{icon}</span>
          <h3 className={`text-lg font-bold ${cardStyle.text}`}>{title}</h3>
        </div>

        {/* Content */}
        <div className="flex-grow space-y-2">
          <p className="text-gray-700 font-medium">{content}</p>
          <p className="text-gray-500 text-sm">{description}</p>
        </div>

        {/* Footer */}
        <div className="mt-4 flex justify-between items-center">
          <span className={`
            px-3 py-1 rounded-full text-xs font-medium
            ${getStatusStyle(status)}
          `}>
            {status}
          </span>
          <span className={`
            text-sm font-medium capitalize
            ${cardStyle.text}
          `}>
            {type}
          </span>
        </div>
      </div>

      {/* Completed Overlay */}
      {status === 'completed' && (
        <div className="absolute inset-0 bg-black bg-opacity-10 rounded-xl flex items-center justify-center">
          <div className="bg-white rounded-full p-2 shadow-lg">
            <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
      )}

      {/* Locked Overlay */}
      {status === 'locked' && (
        <div className="absolute inset-0 bg-black bg-opacity-10 rounded-xl flex items-center justify-center">
          <div className="bg-white rounded-full p-2 shadow-lg">
            <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
        </div>
      )}
    </div>
  );
};

Card.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  type: PropTypes.oneOf(['diary', 'task', 'tool', 'convention', 'punishment', 'wish']).isRequired,
  title: PropTypes.string.isRequired,
  content: PropTypes.string.isRequired,
  description: PropTypes.string,
  points: PropTypes.number,
  status: PropTypes.oneOf(['available', 'locked', 'ongoing', 'completed']),
  icon: PropTypes.string,
  onClick: PropTypes.func
};

Card.defaultProps = {
  description: '',
  points: 0,
  status: 'available',
  icon: '💌',
  onClick: () => {}
};

export default Card;