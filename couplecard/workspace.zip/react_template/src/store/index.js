// src/store/index.js
import { configureStore, createSlice } from '@reduxjs/toolkit';
import notificationReducer from './notificationSlice';
import { ref, onValue, off } from 'firebase/database';
import { database } from '../config/firebase';

const initialUserState = {
  isLoggedIn: false,
  userId: null,
  nickname: '',
  account: '',
  points: 0,
  partnerId: null,
  partnerInfo: null,
  lastUpdate: null,
  connectionStatus: 'disconnected', // 'disconnected', 'pending', 'connected'
  error: null
};

const userSlice = createSlice({
  name: 'user',
  initialState: initialUserState,
  reducers: {
    login: (state, action) => {
      state.isLoggedIn = true;
      state.userId = action.payload.userId;
      state.nickname = action.payload.nickname;
      state.account = action.payload.account;
      state.points = action.payload.points;
      state.partnerId = action.payload.partnerId;
      state.lastUpdate = new Date().toISOString();
      state.error = null;
    },
    logout: (state) => {
      return { ...initialUserState };
    },
    updatePoints: (state, action) => {
      state.points = action.payload;
      state.lastUpdate = new Date().toISOString();
    },
    setPartner: (state, action) => {
      state.partnerId = action.payload.partnerId;
      state.partnerInfo = action.payload.partnerInfo;
      state.connectionStatus = action.payload.partnerId ? 'connected' : 'disconnected';
      state.lastUpdate = new Date().toISOString();
    },
    setPendingConnection: (state) => {
      state.connectionStatus = 'pending';
      state.lastUpdate = new Date().toISOString();
    },
    updatePartnerInfo: (state, action) => {
      state.partnerInfo = {
        ...state.partnerInfo,
        ...action.payload
      };
      state.lastUpdate = new Date().toISOString();
    },
    setError: (state, action) => {
      state.error = action.payload;
      state.lastUpdate = new Date().toISOString();
    },
    clearError: (state) => {
      state.error = null;
    }
  }
});

export const {
  login,
  logout,
  updatePoints,
  setPartner,
  setPendingConnection,
  updatePartnerInfo,
  setError,
  clearError
} = userSlice.actions;

// Thunk for initializing partner listener
export const initializePartnerListener = (userId, partnerId) => (dispatch) => {
  if (!partnerId) return;

  const partnerRef = ref(database, `users/${partnerId}`);
  const listener = onValue(partnerRef, (snapshot) => {
    if (snapshot.exists()) {
      const partnerData = snapshot.val();
      dispatch(updatePartnerInfo({
        nickname: partnerData.nickname,
        account: partnerData.account,
        points: partnerData.points,
        lastActive: partnerData.lastActive
      }));
    } else {
      dispatch(setError('Partner data not found'));
      dispatch(setPartner({ partnerId: null, partnerInfo: null }));
    }
  }, (error) => {
    dispatch(setError(`Failed to sync partner data: ${error.message}`));
  });

  // Return cleanup function
  return () => off(partnerRef, listener);
};

// Configure middleware to handle async actions
const customMiddleware = (store) => (next) => (action) => {
  const result = next(action);
  const state = store.getState();

  // Handle partner synchronization when partner changes
  if (action.type === setPartner.type && action.payload.partnerId) {
    const cleanup = store.dispatch(initializePartnerListener(
      state.user.userId,
      action.payload.partnerId
    ));
    // Store cleanup function for later use
    store.cleanup = cleanup;
  }

  // Cleanup partner listener on logout or partner disconnection
  if (action.type === logout.type || 
      (action.type === setPartner.type && !action.payload.partnerId)) {
    if (store.cleanup) {
      store.cleanup();
      store.cleanup = null;
    }
  }

  return result;
};

const store = configureStore({
  reducer: {
    user: userSlice.reducer,
    notifications: notificationReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore these paths in the serialization check
        ignoredActions: ['setPartner', 'updatePartnerInfo'],
        ignoredPaths: ['user.lastUpdate', 'user.partnerInfo.lastActive'],
      },
    }).concat(customMiddleware),
});

export default store;