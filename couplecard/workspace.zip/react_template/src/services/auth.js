// src/services/auth.js
import { auth, database } from '../config/firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { ref, set, get } from 'firebase/database';

export const loginWithAccount = async (account) => {
  try {
    // Check if account already exists
    const usersSnapshot = await get(ref(database, 'users'));
    const users = usersSnapshot.val() || {};
    
    const existingUser = Object.values(users).find(user => user.account === account);
    if (existingUser) {
      throw new Error('This account is already taken. Please choose a different one.');
    }

    const userCredential = await signInAnonymously(auth);
    const user = userCredential.user;
    
    // Store user data in Realtime Database
    await set(ref(database, `users/${user.uid}`), {
      account,
      nickname: `User_${account}`,
      points: 100,
      partnerId: null,
      createdAt: new Date().toISOString()
    });

    return {
      userId: user.uid,
      account,
      nickname: `User_${account}`,
      points: 100,
      partnerId: null
    };
  } catch (error) {
    throw new Error('Failed to login: ' + error.message);
  }
};

export const getCurrentUser = () => {
  return new Promise((resolve, reject) => {
    const unsubscribe = onAuthStateChanged(auth,
      async (user) => {
        unsubscribe();
        if (user) {
          // Get user data from database
          const snapshot = await get(ref(database, `users/${user.uid}`));
          if (snapshot.exists()) {
            resolve({
              userId: user.uid,
              ...snapshot.val()
            });
          } else {
            resolve(null);
          }
        } else {
          resolve(null);
        }
      },
      reject
    );
  });
};

export const logoutUser = async () => {
  try {
    await auth.signOut();
  } catch (error) {
    throw new Error('Failed to logout: ' + error.message);
  }
};