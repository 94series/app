// src/services/database.js
import { database } from '../config/firebase';
import { ref, set, get, update, onValue, push, remove } from 'firebase/database';

export const sendConnectionRequest = async (fromUserId, toAccount) => {
  try {
    // Find user by account
    const usersSnapshot = await get(ref(database, 'users'));
    const users = usersSnapshot.val();
    const toUser = Object.entries(users).find(([_, userData]) => userData.account === toAccount);
    
    if (!toUser) {
      throw new Error('User not found');
    }

    const [toUserId, toUserData] = toUser;
    const fromUserData = users[fromUserId];
    
    // Check if either user already has a partner
    if (fromUserData.partnerId) {
      throw new Error('You already have a partner');
    }
    if (toUserData.partnerId) {
      throw new Error('This user is already connected with someone else');
    }

    // Check for existing pending requests
    const requestsSnapshot = await get(ref(database, 'connectionRequests'));
    const requests = requestsSnapshot.val() || {};
    const existingRequest = Object.values(requests).find(
      request => 
        (request.fromUserId === fromUserId && request.toUserId === toUserId) ||
        (request.fromUserId === toUserId && request.toUserId === fromUserId)
    );

    if (existingRequest) {
      throw new Error('A connection request already exists between you and this user');
    }
    
    // Create connection request
    const requestRef = push(ref(database, 'connectionRequests'));
    await set(requestRef, {
      fromUserId,
      toUserId,
      status: 'pending',
      createdAt: new Date().toISOString()
    });

    return requestRef.key;
  } catch (error) {
    throw new Error('Failed to send connection request: ' + error.message);
  }
};

export const listenToConnectionRequests = (userId, callback) => {
  const requestsRef = ref(database, 'connectionRequests');
  return onValue(requestsRef, (snapshot) => {
    const requests = [];
    snapshot.forEach((childSnapshot) => {
      const request = childSnapshot.val();
      if (request.toUserId === userId && request.status === 'pending') {
        requests.push({
          id: childSnapshot.key,
          ...request
        });
      }
    });
    callback(requests);
  });
};

export const handleConnectionRequest = async (requestId, status, fromUserId, toUserId) => {
  try {
    await update(ref(database, `connectionRequests/${requestId}`), { status });
    
    if (status === 'accepted') {
      // Update both users' partnerId
      await update(ref(database, `users/${fromUserId}`), { partnerId: toUserId });
      await update(ref(database, `users/${toUserId}`), { partnerId: fromUserId });
    }
  } catch (error) {
    throw new Error('Failed to handle connection request: ' + error.message);
  }
};

export const disconnectPartner = async (userId) => {
  try {
    // Get user data to find partnerId
    const userSnapshot = await get(ref(database, `users/${userId}`));
    const userData = userSnapshot.val();
    
    if (!userData.partnerId) {
      throw new Error('You are not connected with any partner');
    }

    const partnerId = userData.partnerId;

    // Remove partner connection for both users
    await update(ref(database, `users/${userId}`), { partnerId: null });
    await update(ref(database, `users/${partnerId}`), { partnerId: null });

    // Delete any existing connection requests between the users
    const requestsSnapshot = await get(ref(database, 'connectionRequests'));
    const requests = requestsSnapshot.val() || {};
    
    Object.entries(requests).forEach(async ([key, request]) => {
      if ((request.fromUserId === userId && request.toUserId === partnerId) ||
          (request.fromUserId === partnerId && request.toUserId === userId)) {
        await remove(ref(database, `connectionRequests/${key}`));
      }
    });

    return true;
  } catch (error) {
    throw new Error('Failed to disconnect partner: ' + error.message);
  }
};