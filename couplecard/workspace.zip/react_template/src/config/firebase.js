// src/config/firebase.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyDZIN_KKQP3kup9CMq0UQGuYYnuBHWOMeY",
  authDomain: "lovecard-demo.firebaseapp.com",
  databaseURL: "https://lovecard-demo-default-rtdb.firebaseio.com",
  projectId: "lovecard-demo",
  storageBucket: "lovecard-demo.appspot.com",
  messagingSenderId: "667169798892",
  appId: "1:667169798892:web:5c8857df5cf4d7c25b703e"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);