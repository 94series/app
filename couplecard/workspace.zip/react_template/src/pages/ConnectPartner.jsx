// src/pages/ConnectPartner.jsx
import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useDispatch } from 'react-redux';
import { addNotification } from '../store/notificationSlice';
import { sendConnectionRequest, handleConnectionRequest, disconnectPartner } from '../services/database';
import ConnectionRequest from '../components/common/ConnectionRequest';

const ConnectPartner = () => {
  const [partnerAccount, setPartnerAccount] = useState('');
  const [isDisconnecting, setIsDisconnecting] = useState(false);
  const { user } = useAuth();
  const isLoggedIn = !!user;
  const userId = user?.userId;
  const partnerId = user?.partnerId;
  const dispatch = useDispatch();

  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }

  const handleDisconnect = async () => {
    try {
      setIsDisconnecting(true);
      await disconnectPartner(userId);
      dispatch(addNotification({
        type: 'success',
        title: 'Partnership Ended',
        message: 'You have successfully disconnected from your partner.'
      }));
    } catch (error) {
      dispatch(addNotification({
        type: 'error',
        title: 'Disconnection Failed',
        message: error.message
      }));
    } finally {
      setIsDisconnecting(false);
    }
  };

  const handleConnect = async (e) => {
    e.preventDefault();
    if (!partnerAccount.trim() || partnerAccount === user.account) {
      dispatch(addNotification({
        type: 'error',
        title: 'Invalid Input',
        message: 'Please enter a valid partner account.'
      }));
      return;
    }

    try {
      await sendConnectionRequest(userId, partnerAccount);
      dispatch(addNotification({
        type: 'success',
        title: 'Connection Request Sent',
        message: `Your connection request to ${partnerAccount} has been sent.`
      }));
      setPartnerAccount('');
    } catch (error) {
      dispatch(addNotification({
        type: 'error',
        title: 'Connection Request Failed',
        message: error.message
      }));
    }
  };

  if (partnerId) {
    return (
      <div className="max-w-2xl mx-auto mt-8 p-6 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Connected Partner</h2>
        <p className="text-gray-600 mb-6">
          You are currently connected with partner ID: {partnerId}
        </p>
        <button
          onClick={handleDisconnect}
          disabled={isDisconnecting}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
        >
          {isDisconnecting ? 'Disconnecting...' : 'Disconnect Partnership'}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mt-8">
      <div className="bg-white shadow-lg rounded-lg p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Connect with Your Partner</h2>
        <form onSubmit={handleConnect} className="space-y-4">
          <div>
            <label htmlFor="partnerAccount" className="block text-sm font-medium text-gray-700">
              Partner's Account
            </label>
            <input
              type="text"
              id="partnerAccount"
              value={partnerAccount}
              onChange={(e) => setPartnerAccount(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500"
              placeholder="Enter your partner's account"
            />
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500"
          >
            Send Connection Request
          </button>
        </form>
      </div>

      <ConnectionRequest />
    </div>
  );
};

export default ConnectPartner;