// src/pages/Home.jsx
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Navigate, useNavigate } from 'react-router-dom';
import Card from '../components/common/Card';
import { addNotification } from '../store/notificationSlice';
import { setPartner } from '../store';

const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { 
    isLoggedIn, 
    userId, 
    nickname,
    account,
    points,
    partnerId,
    partnerInfo,
    connectionStatus
  } = useSelector((state) => state.user);

  const [cards, setCards] = useState([
    {
      id: 1,
      type: 'diary',
      title: "Today's Story",
      content: 'Share your day with your loved one',
      description: 'Write a heartfelt message about your day',
      points: 10,
      status: 'available',
      icon: '📝'
    },
    {
      id: 2,
      type: 'task',
      title: 'Morning Call',
      content: 'Make a morning call to wake up your partner',
      description: 'Show your care with a sweet morning call',
      points: 15,
      status: 'available',
      icon: '☀️'
    },
    {
      id: 3,
      type: 'wish',
      title: 'Movie Date',
      content: 'Watch a movie together this weekend',
      description: 'Plan a cozy movie night together',
      points: 20,
      status: 'available',
      icon: '🎬'
    }
  ]);

  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }

  const handleCardClick = (card) => {
    if (card.status === 'completed') {
      dispatch(addNotification({
        type: 'info',
        title: 'Card Completed',
        message: 'You have already completed this card'
      }));
      return;
    }

    if (!partnerId) {
      dispatch(addNotification({
        type: 'warning',
        title: 'No Partner Connected',
        message: 'Please connect with your partner first to use cards'
      }));
      return;
    }

    // Update card status
    setCards(prev => prev.map(c => 
      c.id === card.id 
        ? { ...c, status: 'completed' }
        : c
    ));

    dispatch(addNotification({
      type: 'success',
      title: 'Card Activated',
      message: `You've started "${card.title}". Complete it to earn ${card.points} points!`
    }));
  };

  const goToConnect = () => {
    navigate('/connect');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* User Info Section */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900">Your Profile</h2>
            <div className="space-y-2">
              <p className="text-gray-600">Nickname: <span className="text-gray-900 font-medium">{nickname}</span></p>
              <p className="text-gray-600">Account: <span className="text-gray-900 font-medium">{account}</span></p>
              <p className="text-gray-600">Points: <span className="text-pink-600 font-bold">{points}</span></p>
            </div>
          </div>

          {/* Partner Info Section */}
          {partnerId ? (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-gray-900">Partner Profile</h2>
              <div className="space-y-2">
                <p className="text-gray-600">Nickname: <span className="text-gray-900 font-medium">{partnerInfo?.nickname || 'Loading...'}</span></p>
                <p className="text-gray-600">Account: <span className="text-gray-900 font-medium">{partnerInfo?.account || 'Loading...'}</span></p>
                <p className="text-gray-600">Points: <span className="text-pink-600 font-bold">{partnerInfo?.points || 0}</span></p>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {!partnerId ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-lg">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Start Your Love Journey
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Connect with your partner to unlock special cards and create beautiful memories together.
            </p>
            <button 
              onClick={goToConnect}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 transition-colors duration-150"
            >
              <span className="mr-2">💝</span>
              Connect with Partner
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Love Cards</h1>
            <span className="text-sm text-gray-500">Complete cards to earn points!</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cards.map((card) => (
              <Card 
                key={card.id} 
                {...card} 
                onClick={() => handleCardClick(card)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;