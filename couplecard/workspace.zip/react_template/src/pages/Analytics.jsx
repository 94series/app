// src/pages/Analytics.jsx
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';
import EmotionHeatmap from '../components/analytics/EmotionHeatmap';
import PointsChart from '../components/analytics/PointsChart';
import RelationshipProgress from '../components/analytics/RelationshipProgress';

const Analytics = () => {
  const { isLoggedIn, userId, partnerId, points } = useSelector((state) => state.user);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [insights, setInsights] = useState({
    stage: { value: 0, label: 'New' },
    interaction: { value: 0, label: 'None' },
    activity: { value: 0, label: 'None' }
  });

  useEffect(() => {
    if (isLoggedIn && partnerId) {
      // Simulate data loading
      setLoading(true);
      setTimeout(() => {
        setInsights({
          stage: { value: 0.811, label: 'Deep Development' },
          interaction: { value: 42.3, label: 'Wish Fulfillment' },
          activity: { value: 37.7, label: 'Morning' }
        });
        setLoading(false);
      }, 1000);
    }
  }, [isLoggedIn, partnerId]);

  if (!isLoggedIn) {
    return <Navigate to="/login" />;
  }

  if (!partnerId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
          <span className="text-5xl">💝</span>
          <h2 className="text-2xl font-bold text-gray-900">Connect with Your Partner First</h2>
          <p className="text-gray-600">Analytics will be available once you connect with your partner.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
          <span className="text-5xl">😢</span>
          <h2 className="text-xl font-bold text-red-600">Failed to load analytics</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-800">Relationship Analytics</h1>
        <div className="flex items-center space-x-2 text-sm bg-pink-50 px-4 py-2 rounded-full">
          <span className="text-gray-600">Total Points:</span>
          <span className="text-pink-600 font-bold">{points}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="col-span-1 lg:col-span-2">
          <RelationshipProgress />
        </div>
        
        <div className="col-span-1">
          <EmotionHeatmap />
        </div>

        <div className="col-span-1">
          <PointsChart />
        </div>

        <div className="col-span-1 lg:col-span-2">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-xl font-semibold mb-4">Key Insights</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="text-lg font-medium text-blue-700">Relationship Stage</h4>
                <p className="text-blue-600">{insights.stage.label} ({insights.stage.value.toFixed(3)})</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-lg font-medium text-green-700">Top Interaction</h4>
                <p className="text-green-600">{insights.interaction.label} ({insights.interaction.value}%)</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="text-lg font-medium text-purple-700">Peak Activity</h4>
                <p className="text-purple-600">{insights.activity.label} ({insights.activity.value}%)</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;