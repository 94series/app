// src/pages/Login.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const Login = () => {
  const [account, setAccount] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [validationError, setValidationError] = useState('');
  const navigate = useNavigate();
  const { user, login } = useAuth();

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const validateAccount = (account) => {
    if (account.length < 3) {
      return 'Account must be at least 3 characters long';
    }
    if (account.length > 20) {
      return 'Account cannot exceed 20 characters';
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(account)) {
      return 'Account can only contain letters, numbers, underscores and hyphens';
    }
    return '';
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    setError('');
    setValidationError('');
    
    // Validate input
    const validationResult = validateAccount(account.trim());
    if (validationResult) {
      setValidationError(validationResult);
      return;
    }

    setLoading(true);
    
    try {
      await login(account.trim());
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-pink-100 to-purple-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-lg">
        <div>
          <h2 className="mt-2 text-center text-3xl font-extrabold text-gray-900">
            Welcome to Love Card
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Enter your account to start your love journey
          </p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-2">
            <label htmlFor="account" className="block text-sm font-medium text-gray-700">
              Account
            </label>
            <input
              id="account"
              type="text"
              required
              className={`appearance-none rounded-lg relative block w-full px-3 py-3 border ${
                (error || validationError) ? 'border-red-300' : 'border-gray-300'
              } placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-pink-500 focus:border-pink-500 focus:z-10 sm:text-sm`}
              placeholder="Enter your account (3-20 characters)"
              value={account}
              onChange={(e) => {
                setAccount(e.target.value);
                setValidationError('');
                setError('');
              }}
              disabled={loading}
            />
            {validationError && (
              <p className="mt-2 text-sm text-red-600">
                {validationError}
              </p>
            )}
            {error && (
              <p className="mt-2 text-sm text-red-600">
                {error}
              </p>
            )}
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <span className="absolute left-0 inset-y-0 flex items-center pl-3">
                    <svg className="animate-spin h-5 w-5 text-pink-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </span>
                  Processing...
                </>
              ) : (
                'Start Journey'
              )}
            </button>
          </div>
        </form>

        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;