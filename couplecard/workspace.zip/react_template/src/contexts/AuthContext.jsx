// src/contexts/AuthContext.jsx
import React, { createContext } from 'react';
import { useInitializeAuth } from '../hooks/useAuth';
import { loginWithAccount, logoutUser } from '../services/auth';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const { user, loading, error, setUser } = useInitializeAuth();

  const login = async (account) => {
    try {
      const userData = await loginWithAccount(account);
      setUser(userData);
      return userData;
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      await logoutUser();
      setUser(null);
    } catch (error) {
      throw error;
    }
  };

  const value = {
    user,
    loading,
    error,
    login,
    logout,
    setUser
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-600"></div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};