# Project Summary

The Love Card Management System is a web application aimed at enhancing and managing romantic relationships between couples. It serves as an interactive platform that allows partners to engage emotionally through thoughtful interventions. Key features include card management for emotional interactions, a partner connection system to facilitate relationship dynamics, and an analytics dashboard to track relationship metrics. Through gamification of milestones and seamless communication, the system aims to strengthen bonds and foster meaningful connections.

# Project Module Description

## Core Features
1. **User System**: Simplified login allowing users to create accounts and interact without needing a password.
2. **Card Management**: Users can send, receive, and manage various types of cards representing different emotional interactions.
3. **Analytics Dashboard**: Provides insights into user interactions, relationship growth scores, and trends over time.
4. **Partner Connection System**: Facilitates users connecting with their partners through a request system that tracks their relationship status.

# Directory Tree

```plaintext
/data/chats/01nvvd/workspace
+-- analytics
|   +-- visualization_data.json
+-- code.ipynb
+-- docs
|   +-- prd.json
|   +-- prd.md
+-- love_card_class_diagram.mermaid
+-- love_card_sequence_diagram.mermaid
+-- love_card_system_design.md
+-- react_template
    +-- README.md
    +-- eslint.config.js
    +-- index.html
    +-- package.json
    +-- postcss.config.js
    +-- src
    |   +-- App.jsx
    |   +-- components
    |   |   +-- analytics
    |   |   |   +-- EmotionHeatmap.jsx
    |   |   |   +-- PointsChart.jsx
    |   |   |   +-- RelationshipProgress.jsx
    |   |   +-- common
    |   |   |   +-- Card.jsx
    |   |   |   +-- ConnectionRequest.jsx
    |   |   |   +-- ErrorBoundary.jsx
    |   |   |   +-- NotificationSystem.jsx
    |   |   +-- layout
    |   |       +-- Layout.jsx
    |   +-- config
    |   |   +-- firebase.js
    |   +-- contexts
    |   |   +-- AuthContext.jsx
    |   +-- hooks
    |   |   +-- useAuth.js
    |   +-- index.css
    |   +-- main.jsx
    |   +-- pages
    |   |   +-- Analytics.jsx
    |   |   +-- ConnectPartner.jsx
    |   |   +-- Home.jsx
    |   |   +-- Login.jsx
    |   +-- routes.jsx
    |   +-- services
    |   |   +-- auth.js
    |   |   +-- database.js
    |   +-- store
    |   |   +-- index.js
    |   |   +-- notificationSlice.js
    |   +-- styles
    |       +-- index.css
    +-- tailwind.config.js
    +-- template_config.json
    +-- vite.config.js
```

# File Description Inventory

| File Path                                               | Description                                                                                                         |
|--------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| `/src/pages/Login.jsx`                                 | Handles user login and authentication.                                                                             |
| `/src/pages/ConnectPartner.jsx`                        | Manages the partner connection feature, including sending and receiving connection requests.                       |
| `/src/components/common/Card.jsx`                      | Component for displaying cards representing interactions between users.                                          |
| `/src/components/common/NotificationSystem.jsx`       | Displays notifications to users regarding various system events such as connection requests.                        |
| `/src/components/analytics/EmotionHeatmap.jsx`        | Visual representation of emotional interactions over time using a heatmap format.                                  |
| `/src/components/analytics/PointsChart.jsx`           | Displays points (rewards) earned and spent in bar chart format.                                                  |
| `/src/components/analytics/RelationshipProgress.jsx`   | Shows the progress of the relationship based on collected metrics.                                                |
| `/src/store/index.js`                                  | Configures the Redux store for state management, including user and notification states.                           |
| `/src/store/notificationSlice.js`                      | Contains Redux slice for managing notification state.                                                              |
| `/src/config/firebase.js`                              | Firebase initialization and service configuration.                                                                |
| `/src/services/auth.js`                                | Auth service for interacting with Firebase authentication system.                                                  |
| `/src/services/database.js`                            | Manages interactions with Firebase Realtime Database, including connection requests.                               |
| `/src/hooks/useAuth.js`                               | Custom hook for managing authentication state using Firebase's auth services.                                      |
| `/src/contexts/AuthContext.jsx`                        | Provides context for user authentication throughout the application.                                               |

# Technology Stack

- **Frontend**: React, Vite, TailwindCSS
- **State Management**: Redux Toolkit
- **Database**: Firebase Realtime Database
- **Authentication**: Firebase Authentication
- **Data Visualization**: ECharts
- **Others**: Prop-Types, Headless UI (for UI components)

# Usage

1. **Installation**
   - Install dependencies using:
     ```
     pnpm install
     ```

2. **Build the Application**
   - To create a production build:
     ```
     pnpm run build
     ```

3. **Start the Development Server**
   - Run the application using:
     ```
     pnpm run dev
     ```

4. **Environment Variables**
   - Ensure that your Firebase project credentials are configured correctly in `src/config/firebase.js`.


# INSTRUCTION
- Project Path:`/data/chats/01nvvd/workspace/react_template`
- You can search for the file path in the 'Directory Tree';
- After modifying the project files, if this project can be previewed, then you need to reinstall dependencies, restart service and preview;
